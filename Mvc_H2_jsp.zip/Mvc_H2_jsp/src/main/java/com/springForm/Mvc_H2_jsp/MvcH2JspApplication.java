package com.springForm.Mvc_H2_jsp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MvcH2JspApplication {

	public static void main(String[] args) {
		SpringApplication.run(MvcH2JspApplication.class, args);
	}

}
