package com.springForm.Mvc_H2_jsp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MvcH2JspApplicationTests {

	@Test
	void contextLoads() {
	}

}
